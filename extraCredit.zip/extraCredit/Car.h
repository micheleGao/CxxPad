#include <iostream>
#include <string>
using namespace std;

class Car{
    public:
        string brand;
        double weight;
        Car();
        Car(string b, double w);
        ~Car();

};